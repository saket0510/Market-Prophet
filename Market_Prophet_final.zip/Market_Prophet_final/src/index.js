import "./scripts/graph.js";
import "./scripts/closeWelcome";
