const tintOverlay = document.getElementById("tint");
    
function closeWelcomeBox() {

    tintOverlay.style.display = "none";
    
}

function openWelcomeBox() {

    tintOverlay.style.display = "block";
    
}